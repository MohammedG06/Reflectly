import SwiftUI

// MARK: - Models

struct ReflectionEntry: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var emotion: String
    var date: Date
    var text1: String
    var text2: String
}

struct JournalEmotion: Identifiable, Equatable {
    let id: String
    let prompt: String
    let completion: String
}

enum BackgroundStyle: String, CaseIterable {
    case calmBlue, warmSunset, forestGreen, softLavender, deepMood, pastelDaylight
}

// MARK: - Main View

struct ContentView: View {
    
    // MARK: Storage
    
    @AppStorage("savedEntries") private var savedEntriesData: Data = Data()
    @AppStorage("selectedBackground") private var selectedBackgroundRaw: String = BackgroundStyle.calmBlue.rawValue
    
    // MARK: State
    
    @State private var savedEntries: [ReflectionEntry] = []
    
    @State private var selectedEmotion: JournalEmotion? = nil
    @State private var selectedMode: String? = nil
    @State private var step = 1
    
    @State private var text1 = ""
    @State private var text2 = ""
    @State private var entryTitle = ""
    
    @State private var showNaming = false
    @State private var showCompletion = false
    
    @State private var showSaved = false
    @State private var selectedEntry: ReflectionEntry? = nil
    @State private var showDeleteAlert = false
    
    // MARK: Emotions
    
    let emotions: [JournalEmotion] = [
        .init(id: "Overwhelmed", prompt: "What feels most heavy right now?", completion: "You made space for what feels heavy."),
        .init(id: "Anxious", prompt: "What thoughts are looping in your mind?", completion: "You acknowledged your thoughts with courage."),
        .init(id: "Sad", prompt: "What feels painful today?", completion: "You honored your feelings with honesty."),
        .init(id: "Angry", prompt: "What frustrated you?", completion: "You released tension in a healthy way."),
        .init(id: "Lonely", prompt: "Where do you feel disconnected?", completion: "You gave yourself the attention you deserve."),
        .init(id: "Stressed", prompt: "What is overwhelming your energy?", completion: "You paused instead of pushing through."),
        .init(id: "Grateful", prompt: "What are you thankful for?", completion: "You deepened your appreciation."),
        .init(id: "Calm", prompt: "What feels steady or peaceful?", completion: "You strengthened your sense of peace.")
    ]
    
    var selectedBackground: BackgroundStyle {
        BackgroundStyle(rawValue: selectedBackgroundRaw) ?? .calmBlue
    }
    
    var body: some View {
        ZStack {
            
            backgroundGradient
                .ignoresSafeArea()
            
            if let entry = selectedEntry {
                fullEntryView(entry)
            }
            else if showSaved {
                savedReflectionsView
            }
            else if selectedEmotion == nil {
                emotionSelectionView
            }
            else if selectedMode == nil {
                modeSelectionView
            }
            else if showNaming {
                namingView
            }
            else if showCompletion {
                completionView
            }
            else {
                journalView
            }
        }
        .onAppear { loadFromStorage() }
        .animation(.easeInOut(duration: 0.25), value: selectedEmotion)
        .animation(.easeInOut(duration: 0.25), value: showSaved)
        .animation(.easeInOut(duration: 0.25), value: selectedEntry)
    }
    
    // MARK: Background
    
    var backgroundGradient: LinearGradient {
        switch selectedBackground {
        case .calmBlue:
            return LinearGradient(colors: [.blue.opacity(0.8), .indigo], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .warmSunset:
            return LinearGradient(colors: [.orange, .pink], startPoint: .top, endPoint: .bottom)
        case .forestGreen:
            return LinearGradient(colors: [.green, .mint], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .softLavender:
            return LinearGradient(colors: [.purple.opacity(0.8), .blue.opacity(0.6)], startPoint: .top, endPoint: .bottom)
        case .deepMood:
            return LinearGradient(colors: [.black, .indigo], startPoint: .top, endPoint: .bottom)
        case .pastelDaylight:
            return LinearGradient(colors: [.cyan.opacity(0.6), .white], startPoint: .top, endPoint: .bottom)
        }
    }
    
    // MARK: Home Screen
    
    var emotionSelectionView: some View {
        ZStack(alignment: .topTrailing) {
            
            VStack {
                Spacer()
                
                VStack(spacing: 25) {
                    
                    Text("Reflectly")
                        .font(.system(size: 46, weight: .bold))
                        .tracking(1.5)
                        .foregroundColor(.white)
                    
                    Text("A private space for your thoughts.")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.7))
                    
                    Text("Let’s start where you are.")
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundColor(.white)
                    
                    VStack(spacing: 20) {
                        HStack {
                            ForEach(emotions.prefix(4)) { emotionCard($0) }
                        }
                        HStack {
                            ForEach(emotions.suffix(4)) { emotionCard($0) }
                        }
                    }
                    
                    backgroundPicker
                }
                
                Spacer()
            }
            
            Button {
                showSaved = true
            } label: {
                Image(systemName: "folder")
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding(20)
            }
        }
    }
    
    func emotionCard(_ emotion: JournalEmotion) -> some View {
        Button {
            selectedEmotion = emotion
        } label: {
            RoundedRectangle(cornerRadius: 22)
                .fill(Color.white.opacity(0.15))
                .frame(width: 170, height: 100)
                .overlay(
                    Text(emotion.id)
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.white)
                )
        }
        .buttonStyle(.plain)
        .shadow(color: .black.opacity(0.2), radius: 6, x: 0, y: 4)
    }
    
    // MARK: Mode Selection
    
    var modeSelectionView: some View {
        VStack(spacing: 50) {
            
            backButton { selectedEmotion = nil }
            
            Text("How would you like to reflect?")
                .font(.system(size: 30, weight: .semibold))
                .foregroundColor(.white)
            
            HStack(spacing: 40) {
                
                modeCard(title: "Private Reflection", icon: "lock") {
                    selectedMode = "Private"
                }
                
                modeCard(title: "Save for Later", icon: "folder") {
                    selectedMode = "Save"
                }
            }
        }
        .padding()
    }
    
    func modeCard(title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            RoundedRectangle(cornerRadius: 28)
                .fill(.ultraThinMaterial)
                .frame(width: 260, height: 150)
                .overlay(
                    VStack(spacing: 12) {
                        Image(systemName: icon)
                            .font(.system(size: 28))
                        Text(title)
                            .font(.system(size: 18, weight: .medium))
                    }
                        .foregroundColor(.white)
                )
        }
        .buttonStyle(.plain)
        .shadow(color: .black.opacity(0.25), radius: 8, x: 0, y: 6)
    }
    
    // MARK: Journal
    
    var journalView: some View {
        VStack(spacing: 30) {
            
            backButton {
                if step == 2 { step = 1 }
                else { selectedMode = nil }
            }
            
            Text(step == 1 ? selectedEmotion!.prompt : "What do you need right now?")
                .foregroundColor(.white)
            
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(.ultraThinMaterial)
                
                TextEditor(text: step == 1 ? $text1 : $text2)
                    .padding()
                    .scrollContentBackground(.hidden)
                    .background(Color.clear)
                    .foregroundColor(.white)
            }
            .frame(height: 250)
            
            Button(step == 1 ? "Continue" : "Finish") {
                if step == 1 { step = 2 }
                else { finishReflection() }
            }
            .foregroundColor(.white)
        }
        .padding()
    }
    
    func finishReflection() {
        if selectedMode == "Save" {
            showNaming = true
        } else {
            showCompletion = true
        }
    }
    
    // MARK: Naming
    
    var namingView: some View {
        VStack(spacing: 30) {
            
            backButton { showNaming = false }
            
            Text("Name this reflection")
                .foregroundColor(.white)
            
            TextField("Reflection title...", text: $entryTitle)
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(12)
                .foregroundColor(.white)
            
            Button("Save") {
                let entry = ReflectionEntry(
                    title: entryTitle.isEmpty ? "Untitled Reflection" : entryTitle,
                    emotion: selectedEmotion!.id,
                    date: Date(),
                    text1: text1,
                    text2: text2
                )
                savedEntries.append(entry)
                saveToStorage()
                showNaming = false
                showCompletion = true
            }
            .foregroundColor(.white)
        }
        .padding()
    }
    
    // MARK: Completion
    
    var completionView: some View {
        VStack(spacing: 30) {
            Text(selectedEmotion?.completion ?? "")
                .font(.title)
                .foregroundColor(.white)
            
            Button("Done") { resetApp() }
                .foregroundColor(.white)
        }
    }
    
    // MARK: Saved View
    
    var savedReflectionsView: some View {
        VStack(spacing: 20) {
            
            backButton { showSaved = false }
            
            Text("Saved Reflections")
                .font(.system(size: 34, weight: .bold))
                .foregroundColor(.white)
            
            ScrollView {
                VStack(spacing: 18) {
                    ForEach(savedEntries) { entry in
                        Button {
                            selectedEntry = entry
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(entry.title)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                
                                Text(entry.emotion)
                                    .font(.subheadline)
                                    .foregroundColor(.white.opacity(0.75))
                                
                                Text(entry.date.formatted(date: .abbreviated, time: .omitted))
                                    .font(.caption)
                                    .foregroundColor(.white.opacity(0.6))
                            }
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(.ultraThinMaterial)
                            .cornerRadius(18)
                        }
                        .buttonStyle(.plain)
                        .shadow(color: .black.opacity(0.2), radius: 6, x: 0, y: 4)
                    }
                }
                .padding()
            }
        }
    }
    
    // MARK: Full Entry
    
    func fullEntryView(_ entry: ReflectionEntry) -> some View {
        VStack(spacing: 20) {
            
            HStack {
                Button("Back") { selectedEntry = nil }
                Spacer()
                Button(role: .destructive) {
                    showDeleteAlert = true
                } label: {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
            }
            .padding(.horizontal)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(entry.title)
                        .font(.largeTitle)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                    
                    Text(entry.emotion)
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.7))
                    
                    Text(entry.date.formatted(date: .long, time: .omitted))
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.6))
                    
                    Divider()
                        .background(Color.white.opacity(0.4))
                    
                    Text(entry.text1 + "\n\n" + entry.text2)
                        .font(.body)
                        .foregroundColor(.white)
                        .lineSpacing(6)
                }
                .padding()
            }
        }
        .alert("Delete this reflection?", isPresented: $showDeleteAlert) {
            Button("Delete", role: .destructive) {
                savedEntries.removeAll { $0.id == entry.id }
                saveToStorage()
                selectedEntry = nil
            }
            Button("Cancel", role: .cancel) {}
        }
    }
    
    // MARK: Background Picker
    
    var backgroundPicker: some View {
        HStack {
            ForEach(BackgroundStyle.allCases, id: \.self) { style in
                Circle()
                    .fill(previewGradient(for: style))
                    .frame(width: 30, height: 30)
                    .overlay(
                        Circle()
                            .stroke(style.rawValue == selectedBackgroundRaw ? Color.white : Color.clear, lineWidth: 2)
                    )
                    .onTapGesture {
                        selectedBackgroundRaw = style.rawValue
                    }
            }
        }
    }
    
    func previewGradient(for style: BackgroundStyle) -> LinearGradient {
        switch style {
        case .calmBlue: return LinearGradient(colors: [.blue, .indigo], startPoint: .top, endPoint: .bottom)
        case .warmSunset: return LinearGradient(colors: [.orange, .pink], startPoint: .top, endPoint: .bottom)
        case .forestGreen: return LinearGradient(colors: [.green, .mint], startPoint: .top, endPoint: .bottom)
        case .softLavender: return LinearGradient(colors: [.purple, .blue], startPoint: .top, endPoint: .bottom)
        case .deepMood: return LinearGradient(colors: [.black, .gray], startPoint: .top, endPoint: .bottom)
        case .pastelDaylight: return LinearGradient(colors: [.cyan, .white], startPoint: .top, endPoint: .bottom)
        }
    }
    
    // MARK: Helpers
    
    func backButton(action: @escaping () -> Void) -> some View {
        HStack {
            Button("Back", action: action)
                .foregroundColor(.white)
            Spacer()
        }
        .padding(.horizontal)
    }
    
    func resetApp() {
        selectedEmotion = nil
        selectedMode = nil
        step = 1
        text1 = ""
        text2 = ""
        entryTitle = ""
        showCompletion = false
    }
    
    func saveToStorage() {
        if let encoded = try? JSONEncoder().encode(savedEntries) {
            savedEntriesData = encoded
        }
    }
    
    func loadFromStorage() {
        if let decoded = try? JSONDecoder().decode([ReflectionEntry].self, from: savedEntriesData) {
            savedEntries = decoded
        }
    }
}
